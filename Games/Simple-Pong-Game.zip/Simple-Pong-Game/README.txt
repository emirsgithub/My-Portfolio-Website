2D Pong Game
====================================

Welcome to my 2D Pong game made with Unity! This is a finished project at the moment, but has lots of potential for future improvements.

ABOUT THE GAME
-------------
Pong is a classic arcade game that simulates table tennis. This version features a best of 3 match system where players control paddles to hit the ball back and forth. The game includes replay functionality and the option to quit at the end of each match.

FEATURES
--------
* Classic 2D Pong gameplay mechanics
* Best of 3 match system
* Play Again functionality
* Quit game option
* Score tracking for both players
* Smooth paddle movement
* Ball physics and collision detection

HOW TO PLAY
-----------
1. Player 1 uses W/S keys to move their paddle up and down
2. Player 2 uses Up/Down arrow keys to move their paddle
3. Hit the ball with your paddle to send it to the opponent's side
4. Score points when your opponent misses the ball
5. First player to win 2 rounds wins the match

TECHNOLOGIES USED
----------------
* Unity: For game development
* C#: For scripting game logic

FUTURE IMPROVEMENTS
------------------
* Implement AI opponent for single-player mode
* Add customisable paddle and ball skins
* Include background music and sound effects

ACKNOWLEDGMENTS
--------------
* Thanks to BMo on YouTube for the tutorial on this game
* Original Pong game by Atari

CONTACT
-------
If you have any feedback or suggestions, feel free to reach out:
Email: eaa.emirr@gmail.com
LinkedIn: www.linkedin.com/in/emirabidali