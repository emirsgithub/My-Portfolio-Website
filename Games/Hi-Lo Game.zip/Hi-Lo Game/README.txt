This is a very simple 2D Hi-Lo game where players guess whether the next number will be higher or lower.

How to Play
1. A card is displayed on the screen
2. Guess if the next card will be higher or lower by clicking the corresponding button
3. If your guess is correct, you score a point and proceed to the next round
4. If your guess is wrong, the game ends, and your score is displayed
- Ace is the highest value card, not the lowest

Contact
Email: eaa.emirr@gmail.com
LinkedIn: www.linkedin.com/in/emirabidali